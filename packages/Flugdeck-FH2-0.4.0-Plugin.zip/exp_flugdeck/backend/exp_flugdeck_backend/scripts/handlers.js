function h_flugdeck_status(input, ctx) {
  return (0, __fh2_handlers.h_flugdeck_status)(input, ctx)
}

var __fh2_handlers = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // exp_flugdeck/backend/exp_flugdeck_backend/fh2:handlers-entry.js
  var fh2_handlers_entry_exports = {};
  __export(fh2_handlers_entry_exports, {
    h_flugdeck_status: () => status
  });

  // exp_flugdeck/backend/exp_flugdeck_backend/handlers/flugdeck/status.ts
  function status(_input, _ctx) {
    return { service: "flugdeck", version: "0.4.0" };
  }
  return __toCommonJS(fh2_handlers_entry_exports);
})();

//# sourceMappingURL=handlers.js.map
