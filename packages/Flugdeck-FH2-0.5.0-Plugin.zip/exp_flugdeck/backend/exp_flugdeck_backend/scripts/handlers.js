function h_flugdeck_devices(input, ctx) {
  return (0, __fh2_handlers.h_flugdeck_devices)(input, ctx)
}

function h_flugdeck_status(input, ctx) {
  return (0, __fh2_handlers.h_flugdeck_status)(input, ctx)
}

var __fh2_handlers = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // exp_flugdeck/backend/exp_flugdeck_backend/fh2:handlers-entry.js
  var fh2_handlers_entry_exports = {};
  __export(fh2_handlers_entry_exports, {
    h_flugdeck_devices: () => devices,
    h_flugdeck_status: () => status
  });

  // exp_flugdeck/backend/exp_flugdeck_backend/handlers/flugdeck/devices.ts
  function devices(_input, ctx) {
    var _a;
    const page = store.query("live_snapshot", { slot: { eq: "current" } }, { limit: 1 });
    if (!page.ok) throw new Error("Ger\xE4testand nicht verf\xFCgbar.");
    const row = page.data.list[0];
    if (!row) return { source: "unconfigured", fetchedAt: null, devices: [] };
    const time = Number(row.fetched_at_ms);
    const now = Date.parse(ctx.now);
    if (!Number.isSafeInteger(time) || !Number.isSafeInteger(now) || time > now + 5e3 || now - time > 6e4) {
      return { source: "stale", fetchedAt: Number.isSafeInteger(time) ? time : null, devices: [] };
    }
    let snapshot;
    try {
      snapshot = JSON.parse((_a = row.payload) != null ? _a : "");
    } catch (e) {
      throw new Error("Ung\xFCltiger Ger\xE4testand.");
    }
    if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)) throw new Error("Ung\xFCltiger Ger\xE4testand.");
    const candidate = snapshot;
    if (candidate.source !== "live" || candidate.fetchedAt !== time || !Array.isArray(candidate.devices) || candidate.devices.length > 20) {
      throw new Error("Ung\xFCltiger Ger\xE4testand.");
    }
    const allowed = /* @__PURE__ */ new Set(["rc-pro", "rc-plus-2", "m3e", "m3t", "m4t"]);
    const sanitized = candidate.devices.map((entry) => {
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) throw new Error("Ung\xFCltiger Ger\xE4testand.");
      const device = entry;
      if (typeof device.key !== "string" || !/^live-device-\d{1,2}$/.test(device.key) || !allowed.has(String(device.model)) || device.gatewayKey !== null && (typeof device.gatewayKey !== "string" || !/^live-device-\d{1,2}$/.test(device.gatewayKey)) || device.online !== null && typeof device.online !== "boolean") throw new Error("Ung\xFCltiger Ger\xE4testand.");
      return {
        key: device.key,
        model: device.model,
        gatewayKey: device.gatewayKey,
        online: device.online,
        topologyAt: time,
        osdAt: null
      };
    });
    return { schemaVersion: 1, source: "live", fetchedAt: time, devices: sanitized };
  }

  // exp_flugdeck/backend/exp_flugdeck_backend/handlers/flugdeck/status.ts
  function status(_input, _ctx) {
    return { service: "flugdeck", version: "0.5.0" };
  }
  return __toCommonJS(fh2_handlers_entry_exports);
})();

//# sourceMappingURL=handlers.js.map
