function handle(input, ctx) {
  return (0, __fh2_adapters.adapter_0)(input, ctx)
}

var __fh2_adapters = (() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // exp_flugdeck/backend/exp_flugdeck_backend/fh2:adapters-entry.js
  var fh2_adapters_entry_exports = {};
  __export(fh2_adapters_entry_exports, {
    adapter_0: () => handle
  });

  // exp_flugdeck/backend/exp_flugdeck_backend/live/project-topologies.ts
  function object(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function model(name) {
    if (typeof name !== "string") return null;
    const normalized = name.toLowerCase().replace(/\s+/g, " ").trim();
    if (normalized.includes("rc plus 2")) return "rc-plus-2";
    if (normalized.includes("rc pro")) return "rc-pro";
    if (normalized.includes("mavic 3m")) return null;
    if (normalized.includes("mavic 3e") || normalized.includes("mavic 3 enterprise")) return "m3e";
    if (normalized.includes("mavic 3t") || normalized.includes("mavic 3 thermal")) return "m3t";
    if (normalized.includes("matrice 4t")) return "m4t";
    return null;
  }
  function asNode(value) {
    if (!object(value) || typeof value.device_sn !== "string" || !object(value.device_model)) return null;
    const known = model(value.device_model.name);
    return known ? __spreadProps(__spreadValues({}, value), { device_sn: value.device_sn, model: known }) : null;
  }
  function projectTopologies(body, fetchedAt) {
    if (!object(body) || body.code !== 0 || !object(body.data) || !Array.isArray(body.data.list) || body.data.list.length > 100) {
      throw new Error("Ung\xFCltige Topologie-Antwort.");
    }
    const keyed = /* @__PURE__ */ new Map();
    function add(node, gatewaySn) {
      if (!node) return;
      const status = node.is_device_pending_offline === false && node.device_state !== null && typeof node.device_online_status === "boolean" ? node.device_online_status : null;
      const previous = keyed.get(node.device_sn);
      if (previous && (previous.model !== node.model || previous.gatewaySn !== gatewaySn)) throw new Error("Widerspr\xFCchliche Topologie.");
      keyed.set(node.device_sn, { sn: node.device_sn, model: node.model, gatewaySn, online: status });
    }
    for (const item of body.data.list) {
      if (!object(item) || !Array.isArray(item.parents) || item.parents.length > 20) throw new Error("Ung\xFCltige Topologie-Struktur.");
      const host = asNode(item.host);
      const parents = item.parents.map(asNode);
      for (const parent of parents) if ((parent == null ? void 0 : parent.model) === "rc-pro" || (parent == null ? void 0 : parent.model) === "rc-plus-2") add(parent, null);
      if (host && host.model !== "rc-pro" && host.model !== "rc-plus-2") {
        const gateway = parents.find((parent) => parent && (parent.model === "rc-pro" || parent.model === "rc-plus-2"));
        if (gateway) add(host, gateway.device_sn);
      }
    }
    if (keyed.size > 20) throw new Error("Zu viele Ger\xE4te in der Projektion.");
    const sorted = [...keyed.values()].sort((a, b) => a.sn.localeCompare(b.sn));
    const aliases = new Map(sorted.map((device, index) => [device.sn, `live-device-${index + 1}`]));
    return {
      schemaVersion: 1,
      source: "live",
      fetchedAt,
      devices: sorted.map((device) => {
        var _a;
        return {
          key: aliases.get(device.sn),
          model: device.model,
          gatewayKey: device.gatewaySn ? (_a = aliases.get(device.gatewaySn)) != null ? _a : null : null,
          online: device.online,
          topologyAt: fetchedAt,
          osdAt: null
        };
      })
    };
  }

  // exp_flugdeck/backend/exp_flugdeck_backend/adapters/read-devices.ts
  function handle(_input, ctx) {
    const config = platform.getConfig();
    const baseUrl = config.baseUrl;
    const projectUuid = config.projectUuid;
    const token = config.userToken;
    if (typeof baseUrl !== "string" || !/^https:\/\/[A-Za-z0-9.-]+(?::[0-9]{1,5})?\/?$/.test(baseUrl) || typeof projectUuid !== "string" || !/^[a-zA-Z0-9-]{8,64}$/.test(projectUuid) || typeof token !== "string" || !token.trim()) throw new Error("FlightHub-Verbindung nicht konfiguriert.");
    const response = connector.fetch({
      method: "GET",
      url: baseUrl.replace(/\/$/, "") + "/openapi/v2.0/manage/api/v1/projects/" + encodeURIComponent(projectUuid) + "/topologies",
      headers: { "x-user-token": token, "X-Project-Uuid": projectUuid },
      timeoutSec: 10
    });
    if (response.status !== 200) throw new Error("FlightHub-Topologie nicht verf\xFCgbar.");
    let payload;
    try {
      payload = JSON.parse(response.body);
    } catch (e) {
      throw new Error("Ung\xFCltige FlightHub-Antwort.");
    }
    const time = Date.parse(ctx.now);
    if (!Number.isSafeInteger(time)) throw new Error("Ung\xFCltige Abfragezeit.");
    const projected = projectTopologies(payload, time);
    const record = { slot: "current", fetched_at_ms: String(time).padStart(13, "0"), payload: JSON.stringify(projected) };
    const created = store.createIfAbsent("live_snapshot", record, ["slot"]);
    if (!created.ok) throw new Error("Live-Snapshot konnte nicht gespeichert werden.");
    if (!created.data.created) {
      const updated = store.update("live_snapshot", { slot: { eq: "current" }, fetched_at_ms: { lt: record.fetched_at_ms } }, record);
      if (!updated.ok) throw new Error("Live-Snapshot konnte nicht aktualisiert werden.");
    }
    return { count: projected.devices.length };
  }
  return __toCommonJS(fh2_adapters_entry_exports);
})();

//# sourceMappingURL=adapter.js.map
